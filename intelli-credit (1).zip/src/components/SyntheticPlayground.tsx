/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Database, Download, Sparkles, Server, CheckCircle2, TrendingUp, HelpCircle } from 'lucide-react';

export default function SyntheticPlayground() {
  const [loading, setLoading] = useState(false);
  const [dataStats, setDataStats] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const startGeneratingDataset = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/generate-synthetic-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to generate dataset');
      setDataStats(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Dataset generation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-zinc-200 shadow-sm space-y-6" id="dataset-playground-panel">
      
      {/* Workspace Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-100 pb-5">
        <div>
          <h3 className="font-sans font-bold text-zinc-950 text-lg flex items-center gap-2">
            <Database className="w-5 h-5 text-zinc-650" />
            ML Synthetic Credit Registry Generator
          </h3>
          <p className="text-zinc-500 text-xs mt-1">
            Build and download verified credit registers of 5,000+ records containing balanced risk labels, incomes and ratiometrics.
          </p>
        </div>

        <button
          onClick={startGeneratingDataset}
          disabled={loading}
          className="inline-flex items-center gap-2 bg-black hover:bg-zinc-800 text-white text-xs font-bold px-4 py-2.5 rounded-lg transition-all shadow-md cursor-pointer disabled:opacity-50"
          id="btn-play-trigger-synthetics"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              Generating 5000+ Records...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              Run ML Registry Builder
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-100 p-3 text-rose-800 text-xs rounded-lg font-medium">
          {error}
        </div>
      )}

      {/* Statistics outcomes displayer */}
      {dataStats ? (
        <div className="space-y-6 animate-fade-in" id="dataset-stats-results">
          
          {/* Top Row: General stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-zinc-50 border border-zinc-150 p-4 rounded-lg">
              <span className="text-[10px] font-mono tracking-wider text-zinc-400 block uppercase font-bold">Total Generated Rows</span>
              <p className="text-2xl font-black text-zinc-900 mt-1">{dataStats.totalRecords.toLocaleString()} Records</p>
            </div>
            <div className="bg-zinc-50 border border-zinc-150 p-4 rounded-lg">
              <span className="text-[10px] font-mono tracking-wider text-zinc-400 block uppercase font-bold">Heuristic Factors Count</span>
              <p className="text-2xl font-black text-zinc-900 mt-1">{dataStats.columnsCount} Columns</p>
            </div>
            <div className="bg-zinc-50 border border-zinc-150 p-4 rounded-lg">
              <span className="text-[10px] font-mono tracking-wider text-zinc-400 block uppercase font-bold">Business applications</span>
              <p className="text-2xl font-black text-zinc-900 mt-1">{dataStats.businessCount.toLocaleString()}</p>
            </div>
            <div className="bg-zinc-50 border border-zinc-150 p-4 rounded-lg">
              <span className="text-[10px] font-mono tracking-wider text-zinc-400 block uppercase font-bold">Personal applications</span>
              <p className="text-2xl font-black text-zinc-900 mt-1">{dataStats.personalCount.toLocaleString()}</p>
            </div>
          </div>

          {/* Balanced Class Index representation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            
            <div className="border border-zinc-150 p-5 rounded-lg space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Class Balance Label Distributions</h4>
              
              <div className="space-y-3.5 text-xs font-semibold">
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-zinc-650 flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-emerald-500 rounded-full" /> Label 0: Low Risk Default probabilities</span>
                    <span className="text-zinc-900 font-bold">{dataStats.lowRiskPercentage}%</span>
                  </div>
                  <div className="w-full bg-zinc-100 h-2 rounded-full overflow-hidden">
                    <div style={{ width: `${dataStats.lowRiskPercentage}%` }} className="bg-emerald-500 h-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-zinc-650 flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-amber-400 rounded-full" /> Label 1: Medium Risk Default probabilities</span>
                    <span className="text-zinc-900 font-bold">{dataStats.mediumRiskPercentage}%</span>
                  </div>
                  <div className="w-full bg-zinc-100 h-2 rounded-full overflow-hidden">
                    <div style={{ width: `${dataStats.mediumRiskPercentage}%` }} className="bg-amber-400 h-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-zinc-650 flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-rose-500 rounded-full" /> Label 2: High Risk Default / Rejected</span>
                    <span className="text-zinc-900 font-bold">{dataStats.highRiskPercentage}%</span>
                  </div>
                  <div className="w-full bg-zinc-100 h-2 rounded-full overflow-hidden">
                    <div style={{ width: `${dataStats.highRiskPercentage}%` }} className="bg-rose-500 h-full" />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Underwriter registry Export</h4>
              <p className="text-xs text-zinc-500 leading-relaxed font-medium">
                The database exports a comprehensive credit matrix mapped with PAN registers, ratios, EBITDA coverage indexes, litigation records, and actual default labels. Ideal to seed XGBoost, Random Forest or Logistic regression classifiers model.
              </p>
              
              <a
                href="/synthetic_credit_risk_dataset.csv"
                download="synthetic_credit_risk_dataset.csv"
                className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-lg transition-all shadow-md cursor-pointer"
                id="btn-download-synthetics-csv"
              >
                <Download className="w-4 h-4" />
                Download Registries (synthetic_credit_risk_dataset.csv)
              </a>
            </div>

          </div>

          {/* Table Preview */}
          <div className="border border-zinc-150 rounded-lg overflow-hidden">
            <div className="p-4 bg-zinc-50 border-b border-zinc-150 font-mono text-[10px] text-zinc-500 uppercase font-bold">
              Sub-sample register Preview (Top 3 records)
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-[10px] bg-zinc-50/50">
                <thead>
                  <tr className="border-b border-zinc-150 text-zinc-550">
                    <th className="px-4 py-2">company_id</th>
                    <th className="px-4 py-2">loan_type</th>
                    <th className="px-4 py-2">annual_revenue</th>
                    <th className="px-4 py-2">debt_to_equity_ratio</th>
                    <th className="px-4 py-2">credit_history_score</th>
                    <th className="px-4 py-2 text-center">credit_risk_label</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-150">
                  {dataStats.sample.map((row: any, idx: number) => (
                    <tr key={idx}>
                      <td className="px-4 py-2">{row.company_id}</td>
                      <td className="px-4 py-2 font-bold">{row.loan_type}</td>
                      <td className="px-4 py-2">₹{row.annual_revenue || row.monthly_income}L</td>
                      <td className="px-4 py-2">{row.debt_to_equity_ratio || 'N/A'}</td>
                      <td className="px-4 py-2">{row.credit_history_score}</td>
                      <td className="px-4 py-2 text-center font-bold">
                        <span className={`px-2 py-0.5 rounded ${
                          row.credit_risk_label === 0 ? 'bg-emerald-50 text-emerald-600' : (row.credit_risk_label === 1 ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600')
                        }`}>
                          {row.credit_risk_label}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      ) : (
        <div className="text-center p-8 bg-zinc-50 rounded-xl border border-dashed border-zinc-200" id="dataset-playground-inactive">
          <Server className="w-8 h-8 text-zinc-400 mx-auto mb-3" />
          <p className="font-semibold text-sm text-zinc-700">Database Engine Dormant</p>
          <p className="text-xs text-zinc-555 text-zinc-500 mt-1 max-w-sm mx-auto leading-relaxed">
            Click &quot;Run ML Registry Builder&quot; above to trigger 5,000+ financial evaluations and compiled credit histories.
          </p>
        </div>
      )}

    </div>
  );
}
