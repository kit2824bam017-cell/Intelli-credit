/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  FileText, 
  TrendingUp, 
  Percent, 
  IndianRupee, 
  ShieldAlert, 
  Clock, 
  Building2, 
  Plus, 
  User, 
  CheckCircle2, 
  XSquare,
  ArrowUpRight,
  Database
} from 'lucide-react';
import { LoanType, DashboardStats, CreditAppraisalMemo } from '../types.js';

interface DashboardInsightsProps {
  stats: DashboardStats;
  onSelectApplication: (id: string) => void;
  onTriggerNewLoan: (type: LoanType) => void;
  triggerSyntheticDataset: () => void;
}

export default function DashboardInsights({
  stats,
  onSelectApplication,
  onTriggerNewLoan,
  triggerSyntheticDataset
}: DashboardInsightsProps) {
  
  // Calculate average requested loan amounts
  const recentApps = stats?.recentApplications || [];

  return (
    <div className="space-y-8 animate-fade-in" id="dashboard-insights-panel">
      {/* Upper row: Welcome & Actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-zinc-200 pb-6">
        <div>
          <h1 className="text-3xl font-sans font-bold tracking-tight text-zinc-900">Credit Risk Underwriting</h1>
          <p className="text-zinc-500 text-sm mt-1">Real-time analytical risk scoring, GST auditing, and AI loan appraisal decisioning.</p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => onTriggerNewLoan(LoanType.PERSONAL)}
            className="inline-flex items-center gap-2 bg-white hover:bg-zinc-50 text-zinc-800 text-sm font-medium px-4 py-2.5 rounded-lg border border-zinc-200 shadow-sm transition-all"
            id="btn-new-personal-loan"
          >
            <User className="w-4 h-4 text-zinc-500" />
            New Personal Application
          </button>
          
          <button
            onClick={() => onTriggerNewLoan(LoanType.BUSINESS)}
            className="inline-flex items-center gap-2 bg-black hover:bg-zinc-800 text-white text-sm font-medium px-4 py-2.5 rounded-lg shadow-md transition-all"
            id="btn-new-business-loan"
          >
            <Building2 className="w-4 h-4" />
            New MSME / Business Application
          </button>
        </div>
      </div>

      {/* Main KPI metrics bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5" id="kpi-grid">
        <div className="bg-white p-5 rounded-xl border border-zinc-150 shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-mono tracking-wider uppercase text-zinc-400">Total Pipeline</span>
            <h3 className="text-3xl font-sans font-extrabold text-zinc-900">{stats.totalApplications}</h3>
            <span className="text-xs text-zinc-500 flex items-center gap-1 mt-1">
              <Clock className="w-3.5 h-3.5" /> Checked in-memory
            </span>
          </div>
          <div className="p-3 bg-zinc-100 rounded-lg">
            <FileText className="w-5 h-5 text-zinc-600" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-zinc-150 shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-mono tracking-wider uppercase text-zinc-400">Avg Bureau Rating</span>
            <h3 className="text-3xl font-sans font-extrabold text-zinc-900">{stats.averageCreditScore}</h3>
            <span className="text-xs text-green-600 font-medium flex items-center gap-0.5 mt-1">
              <TrendingUp className="w-3.5 h-3.5" /> High Risk filtered
            </span>
          </div>
          <div className="p-3 bg-zinc-100 rounded-lg">
            <Percent className="w-5 h-5 text-zinc-600" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-zinc-150 shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-mono tracking-wider uppercase text-zinc-400">Approval Rate</span>
            <h3 className="text-3xl font-sans font-extrabold text-zinc-900">{stats.approvalRate}%</h3>
            <span className="text-xs text-zinc-500 flex items-center gap-1 mt-1">
              Based on credit risk limits
            </span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-lg">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-zinc-150 shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-mono tracking-wider uppercase text-zinc-400">Capital Committed</span>
            <h3 className="text-3xl font-sans font-extrabold text-zinc-900">₹{stats.totalApprovedAmount}L</h3>
            <span className="text-xs text-emerald-600 font-medium flex items-center gap-0.5 mt-1">
              Active loan liquidity
            </span>
          </div>
          <div className="p-3 bg-zinc-100 rounded-lg">
            <IndianRupee className="w-5 h-5 text-zinc-600" />
          </div>
        </div>
      </div>

      {/* Grid: Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-charts-layout">
        {/* SVG Distribution Chart */}
        <div className="bg-white p-6 rounded-xl border border-zinc-150 shadow-sm col-span-1 lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
            <h3 className="font-sans font-bold text-zinc-800">Portfolio Growth & Compliance</h3>
            <span className="text-xs font-mono bg-zinc-100 text-zinc-650 px-2.5 py-1 rounded-full font-medium">Monthly Outlays</span>
          </div>

          <div className="relative h-60 w-full flex items-end justify-between px-2 pt-6">
            {/* SVG horizontal gridlines */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-8 text-[10px] font-mono text-zinc-400">
              <div className="border-b border-dashed border-zinc-100 w-full pb-1">₹50 Lakhs</div>
              <div className="border-b border-dashed border-zinc-100 w-full pb-1">₹35 Lakhs</div>
              <div className="border-b border-dashed border-zinc-100 w-full pb-1">₹20 Lakhs</div>
              <div className="border-b border-dashed border-zinc-100 w-full pb-1">₹5 Lakhs</div>
            </div>

            {/* Bars for historical turnovers */}
            <div className="w-full flex justify-around items-end z-10 h-48">
              {[
                { month: 'Jan 26', personal: 12, business: 35 },
                { month: 'Feb 26', personal: 15, business: 42 },
                { month: 'Mar 26', personal: 20, business: 30 },
                { month: 'Apr 26', personal: 18, business: 55 },
                { month: 'May 26', personal: 25, business: 85 },
                { month: 'Jun 26 (Current)', personal: stats.totalApplications * 4, business: stats.totalApprovedAmount }
              ].map((item, idx) => {
                const totalVal = Math.max(10, item.personal + item.business);
                const pHeight = `${(item.personal / 120) * 100}%`;
                const bHeight = `${(item.business / 120) * 100}%`;

                return (
                  <div key={idx} className="flex flex-col items-center group space-y-2 w-12 text-center">
                    <div className="w-full flex justify-center items-end gap-1 h-36">
                      <div 
                        style={{ height: pHeight }} 
                        className="w-3 bg-zinc-300 group-hover:bg-zinc-400 rounded-t-sm transition-all"
                        title={`Personal: ₹${item.personal}L`}
                      />
                      <div 
                        style={{ height: bHeight }} 
                        className="w-4 bg-black group-hover:bg-zinc-850 rounded-t-sm transition-all"
                        title={`Business: ₹${item.business}L`}
                      />
                    </div>
                    <span className="text-[10px] font-sans text-zinc-500 font-medium">{item.month}</span>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-6 text-xs text-zinc-500 pt-2 border-t border-zinc-50">
            <span className="flex items-center gap-1.5 font-medium"><span className="w-3 h-3 bg-zinc-300 rounded-sm"></span> Personal Loans</span>
            <span className="flex items-center gap-1.5 font-medium"><span className="w-3.5 h-3.5 bg-black rounded-sm"></span> Business MSME Outlays</span>
          </div>
        </div>

        {/* Portfolio Risk circular stats */}
        <div className="bg-white p-6 rounded-xl border border-zinc-150 shadow-sm space-y-6">
          <div className="border-b border-zinc-100 pb-3">
            <h3 className="font-sans font-bold text-zinc-800">Risk Allocation Index</h3>
          </div>

          <div className="flex flex-col items-center justify-center py-4 space-y-4">
            <div className="relative w-40 h-40 flex items-center justify-center">
              {/* Simple beautiful concentric arcs / pie simulated */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="#f4f4f5" strokeWidth="8" fill="transparent" />
                <circle cx="50" cy="50" r="40" stroke="#000000" strokeWidth="8" strokeDasharray="251.2" strokeDashoffset={60} fill="transparent" className="transition-all duration-500" />
                <circle cx="50" cy="50" r="40" stroke="#a1a1aa" strokeWidth="8" strokeDasharray="251.2" strokeDashoffset={180} fill="transparent" className="transition-all duration-500" />
                <circle cx="50" cy="50" r="40" stroke="#fda4af" strokeWidth="8" strokeDasharray="251.2" strokeDashoffset={230} fill="transparent" className="transition-all duration-500" />
              </svg>
              <div className="absolute text-center">
                <span className="text-xs text-zinc-400 font-mono tracking-wider">SECURE</span>
                <p className="text-xl font-bold font-sans text-zinc-900">72% Low</p>
              </div>
            </div>

            <div className="w-full space-y-2 text-xs">
              <div className="flex items-center justify-between font-medium">
                <span className="flex items-center gap-1.5 text-zinc-650"><span className="w-2.5 h-2.5 bg-black rounded-full" /> Low Risk</span>
                <span className="text-zinc-900 font-bold">72%</span>
              </div>
              <div className="flex items-center justify-between font-medium">
                <span className="flex items-center gap-1.5 text-zinc-650"><span className="w-2.5 h-2.5 bg-zinc-450 bg-zinc-400 rounded-full" /> Medium Risk</span>
                <span className="text-zinc-900 font-bold">20%</span>
              </div>
              <div className="flex items-center justify-between font-medium">
                <span className="flex items-center gap-1.5 text-zinc-650"><span className="w-2.5 h-2.5 bg-rose-300 rounded-full" /> High Risk Limit</span>
                <span className="text-zinc-900 font-bold">8%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section: Queue list */}
      <div className="bg-white rounded-xl border border-zinc-150 shadow-sm" id="pipeline-applications-list">
        <div className="p-6 border-b border-zinc-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 className="font-sans font-bold text-zinc-900">Appraisal Pipelines</h3>
            <p className="text-xs text-zinc-500 mt-0.5">Click any application to audit full credit scoring, CAM appraisal tables, or print PDF.</p>
          </div>
          <button 
            onClick={triggerSyntheticDataset}
            className="inline-flex items-center gap-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-xs font-semibold px-3.5 py-2 rounded-lg transition-all"
            id="btn-dataset-playground-nav"
          >
            <Database className="w-4 h-4 text-zinc-500" />
            ML Synthetic Engine (5000+ data)
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-zinc-50 font-mono text-[10px] uppercase tracking-wider text-zinc-500 border-b border-zinc-100">
                <th className="px-6 py-3.5">ID</th>
                <th className="px-6 py-3.5">Borrower Profile</th>
                <th className="px-6 py-3.5">Category</th>
                <th className="px-6 py-3.5">Requested Facility</th>
                <th className="px-6 py-3.5 text-center">Score Index</th>
                <th className="px-6 py-3.5 text-center">Status</th>
                <th className="px-6 py-3.5 text-right">Appraise</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {recentApps.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-zinc-400 font-sans">
                    No active appraisal records. Add a new Personal or Business application to initiate underwriting scoring.
                  </td>
                </tr>
              ) : (
                recentApps.map((app) => (
                  <tr 
                    key={app.id} 
                    className="hover:bg-zinc-50/75 transition-all group"
                  >
                    <td className="px-6 py-4 font-mono font-bold text-zinc-900 select-all">{app.id}</td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-zinc-800 group-hover:text-black transition-all">{app.borrowerName}</div>
                      <div className="text-[11px] text-zinc-550 text-zinc-400 mt-0.5">{app.createdAt}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-mono px-2.5 py-0.5 rounded-full font-bold ${
                        app.loanType === LoanType.PERSONAL ? 'bg-zinc-100 text-zinc-800' : 'bg-black text-white'
                      }`}>
                        {app.loanType}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-semibold text-zinc-900">₹{app.requestedAmount} Lakhs</div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className={`text-sm font-extrabold ${
                          app.creditScore >= 78 ? 'text-emerald-600' : (app.creditScore >= 58 ? 'text-amber-500' : 'text-rose-500')
                        }`}>
                          {app.creditScore}
                        </span>
                        <div className="w-10 bg-zinc-100 h-1 rounded-full mt-1 overflow-hidden">
                          <div 
                            style={{ width: `${app.creditScore}%` }} 
                            className={`h-full ${
                              app.creditScore >= 78 ? 'bg-emerald-500' : (app.creditScore >= 58 ? 'bg-amber-400' : 'bg-rose-500')
                            }`}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
                        app.status === 'Approved' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {app.status === 'Approved' ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <XSquare className="w-3.5 h-3.5 text-rose-600" />
                        )}
                        {app.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => onSelectApplication(app.id)}
                        className="inline-flex items-center gap-1 bg-white hover:bg-zinc-900 hover:text-white hover:border-black text-zinc-800 text-xs font-semibold px-3 py-1.5 rounded-md border border-zinc-200 transition-all cursor-pointer shadow-sm"
                        id={`btn-view-app-${app.id}`}
                      >
                        Appraisal Memo
                        <ArrowUpRight className="w-3 h-3 text-zinc-400 group-hover:text-white" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
