/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Building2, Percent, CheckCircle2, AlertTriangle, ArrowRight, ShieldCheck } from 'lucide-react';
import { LoanType, IndustryType } from '../types.js';

interface BusinessAnalysisFormProps {
  initialData: any;
  onSubmit: (formData: any) => void;
  loading: boolean;
}

export default function BusinessAnalysisForm({ initialData, onSubmit, loading }: BusinessAnalysisFormProps) {
  const [formData, setFormData] = useState({
    borrowerName: '',
    requestedAmount: '45',
    industryType: IndustryType.SERVICES,
    gstNumber: '27AAPCZ5984A1ZS',
    annualTurnover: '280',
    netProfit: '35',
    currentAssets: '54',
    currentLiabilities: '30',
    totalLiabilities: '110',
    totalEquity: '170',
    ebitda: '52',
    revenueGrowthRate: '18',
    address: 'Building A3, MIDC Industrial Area, Pune, Maharashtra 411018',
  });

  const [gstAlert, setGstAlert] = useState<string | null>(null);

  // Load from OCR parsed outcomes automatically upon selection
  useEffect(() => {
    if (initialData) {
      setFormData({
        borrowerName: initialData.borrowerName || '',
        requestedAmount: '50', // Default relative to turnovers
        industryType: initialData.gstNumber ? IndustryType.SERVICES : IndustryType.SERVICES,
        gstNumber: initialData.gstNumber || '27AAPCZ5984A1ZS',
        annualTurnover: String(initialData.annualTurnover ? Math.round(initialData.annualTurnover / 100000) : '280'),
        netProfit: String(initialData.netProfit ? Math.round(initialData.netProfit / 100000) : '35'),
        currentAssets: String(initialData.currentAssets ? Math.round(initialData.currentAssets / 100000) : '54'),
        currentLiabilities: String(initialData.currentLiabilities ? Math.round(initialData.currentLiabilities / 100000) : '30'),
        totalLiabilities: String(initialData.totalLiabilities ? Math.round(initialData.totalLiabilities / 100000) : '110'),
        totalEquity: String(initialData.totalEquity ? Math.round(initialData.totalEquity / 100000) : '170'),
        ebitda: String(initialData.ebitda ? Math.round(initialData.ebitda / 100000) : '52'),
        revenueGrowthRate: '18',
        address: initialData.address || 'MIDC Industrial Area, Pune, Maharashtra 411018',
      });
    }
  }, [initialData]);

  // Form input changes and format validations
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (name === 'gstNumber') {
      const gstRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
      const isFormatValid = gstRegex.test(value.toUpperCase().trim());
      if (value.length > 0 && !isFormatValid) {
        setGstAlert('Invalid structure format code (Expected India PAN-based 15 Chars GSTIN).');
      } else {
        setGstAlert(null);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  // Live computed financial indicators prior to submission
  const ca = parseFloat(formData.currentAssets) || 1;
  const cl = parseFloat(formData.currentLiabilities) || 1;
  const liabilities = parseFloat(formData.totalLiabilities) || 0;
  const equity = parseFloat(formData.totalEquity) || 1;
  
  const currentRatio = Math.round((ca / cl) * 100) / 100;
  const dTERatio = Math.round((liabilities / equity) * 100) / 100;

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in" id="business-app-entry-form">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        
        {/* Company Name */}
        <div className="space-y-1.5 col-span-1 md:col-span-2">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Business / Company Name</label>
          <div className="relative">
            <input
              type="text"
              name="borrowerName"
              required
              value={formData.borrowerName}
              onChange={handleChange}
              placeholder="e.g. Acme Industrial Castings Private Limited"
              className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
            />
            <Building2 className="absolute left-3 top-3.5 w-4 h-4 text-zinc-400" />
          </div>
        </div>

        {/* Requested Amount */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Requested amount (₹ Lakhs)</label>
          <div className="relative">
            <input
              type="number"
              name="requestedAmount"
              required
              min="1"
              value={formData.requestedAmount}
              onChange={handleChange}
              className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-semibold text-zinc-900"
            />
            <span className="absolute left-3 top-2.5 text-zinc-400 font-bold text-sm">₹</span>
          </div>
        </div>

        {/* Industry Type Indicator */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Industrial sector</label>
          <select
            name="industryType"
            value={formData.industryType}
            onChange={handleChange}
            className="w-full px-3 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-semibold text-zinc-800"
          >
            {Object.values(IndustryType).map((i) => (
              <option key={i} value={i}>{i}</option>
            ))}
          </select>
        </div>

        {/* GST Registration Number */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">GST Registration (GSTIN)</label>
          <input
            type="text"
            name="gstNumber"
            required
            value={formData.gstNumber}
            onChange={handleChange}
            placeholder="e.g. 27AAPCS1234F1Z5"
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-mono tracking-wider font-bold text-zinc-900"
          />
          {gstAlert && (
            <p className="text-[10px] text-amber-600 font-medium flex items-center gap-1 mt-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              {gstAlert}
            </p>
          )}
        </div>

        {/* Annualized Turnover */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Annual Revenue / Turnover (₹ Lakhs)</label>
          <input
            type="number"
            name="annualTurnover"
            required
            value={formData.annualTurnover}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        {/* Net Profits */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Annual Net Profits (₹ Lakhs)</label>
          <input
            type="number"
            name="netProfit"
            required
            value={formData.netProfit}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        {/* Operating EBITDA */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">EBITDA Earnings (₹ Lakhs)</label>
          <input
            type="number"
            name="ebitda"
            required
            value={formData.ebitda}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        {/* Balance Sheets Items: Assets & Liabilities */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Total Current Assets (₹ Lakhs)</label>
          <input
            type="number"
            name="currentAssets"
            required
            value={formData.currentAssets}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Total Current Liabilities (₹ Lakhs)</label>
          <input
            type="number"
            name="currentLiabilities"
            required
            value={formData.currentLiabilities}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Total Liabilities (₹ Lakhs)</label>
          <input
            type="number"
            name="totalLiabilities"
            required
            value={formData.totalLiabilities}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        {/* Shareholder Equity */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Total Corporate Equity (₹ Lakhs)</label>
          <input
            type="number"
            name="totalEquity"
            required
            value={formData.totalEquity}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        {/* Revenue Growth rate */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Annual Growth Rate (%)</label>
          <input
            type="number"
            name="revenueGrowthRate"
            required
            value={formData.revenueGrowthRate}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

        {/* Geographic location and address */}
        <div className="col-span-1 md:col-span-2 lg:col-span-3 space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Registered Office Corporate Address</label>
          <input
            type="text"
            name="address"
            required
            value={formData.address}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

      </div>

      {/* Ratios Previewer */}
      <div className="p-4 rounded-lg bg-zinc-50 border border-zinc-200 space-y-2 text-xs">
        <h4 className="font-mono text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1">
          <ShieldCheck className="w-4 h-4 text-zinc-500" />
          Balance Sheet Ratios Audit Preview
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div>
            <p className="text-zinc-500">Current Ratio (Goal &gt; 1.5):</p>
            <p className={`font-bold text-sm mt-0.5 ${currentRatio < 1.2 ? 'text-rose-600' : 'text-emerald-600'}`}>
              {currentRatio} {currentRatio < 1.2 ? '(Under liquidity stress)' : '(Robust current assets coverage)'}
            </p>
          </div>
          <div>
            <p className="text-zinc-500">Debt-to-Equity Ratio (Goal &lt; 2.0):</p>
            <p className={`font-bold text-sm mt-0.5 ${dTERatio > 2.0 ? 'text-rose-600' : 'text-emerald-600'}`}>
              {dTERatio}x {dTERatio > 2.0 ? '(Highly geared balance structures)' : '(Under leveraged security)'}
            </p>
          </div>
        </div>
      </div>

      <div className="pt-3 flex justify-end">
        <button
          type="submit"
          disabled={loading}
          className="inline-flex items-center gap-2 bg-black hover:bg-zinc-850 hover:shadow-lg text-white font-medium text-sm px-6 py-3 rounded-lg shadow-md transition-all cursor-pointer"
          id="btn-business-form-submit"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              Evaluating Commercial Risk...
            </>
          ) : (
            <>
              Analyze Risks & Recommendation
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>

    </form>
  );
}
