/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, ShieldAlert, FileMinus, ArrowRight, IndianRupee } from 'lucide-react';
import { LoanType } from '../types.js';

interface PersonalAnalysisFormProps {
  initialData: any;
  onSubmit: (formData: any) => void;
  loading: boolean;
}

export default function PersonalAnalysisForm({ initialData, onSubmit, loading }: PersonalAnalysisFormProps) {
  const [formData, setFormData] = useState({
    borrowerName: '',
    requestedAmount: '12',
    monthlyIncome: '120000',
    existingEMIs: '18000',
    employmentStabilityYears: '4.5',
    creditBureauScore: '740',
    panNumber: 'BMKPS1234F',
    aadhaarNumber: '4820 1930 2049',
    address: 'Sector 55, Gurgaon, India',
  });

  // Load from OCR parsed outcomes automatically upon selection
  useEffect(() => {
    if (initialData) {
      setFormData({
        borrowerName: initialData.borrowerName || '',
        requestedAmount: '15', // default sandbox multiplier matching income
        monthlyIncome: String(initialData.incomeAmount || '120000'),
        existingEMIs: String(initialData.taxDeductions || '15000'),
        employmentStabilityYears: String(initialData.stabilityAlerts?.includes('Strong') ? '6.0' : '3.5'),
        creditBureauScore: '770',
        panNumber: initialData.panNumber || 'BMKPS1234F',
        aadhaarNumber: initialData.aadhaarNumber || '4820 1930 2049',
        address: 'Sector 55, Gurgaon, India',
      });
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  // Live computed heuristic metrics inside form boundaries
  const amount = parseFloat(formData.requestedAmount) || 0;
  const income = parseFloat(formData.monthlyIncome) || 1;
  const emi = parseFloat(formData.existingEMIs) || 0;
  const currentDti = Math.round((emi / income) * 100);
  const projectedEmi = amount * 100000 * 0.022; // rough estimated EMI (e.g. 2.2% monthly)
  const projectedDti = Math.round(((emi + projectedEmi) / income) * 100);

  return (
    <form onSubmit={handleSubmit} className="space-y-6" id="personal-app-entry-form">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Name Fields */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Borrower Legal Name</label>
          <div className="relative">
            <input
              type="text"
              name="borrowerName"
              required
              value={formData.borrowerName}
              onChange={handleChange}
              placeholder="e.g. Vijay Kumar Sharma"
              className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
            />
            <User className="absolute left-3 top-3.5 w-4 h-4 text-zinc-400" />
          </div>
        </div>

        {/* Requested Amount (₹ Lakhs) */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Requested Facility (₹ Lakhs)</label>
          <div className="relative">
            <input
              type="number"
              name="requestedAmount"
              required
              min="0.5"
              step="0.1"
              value={formData.requestedAmount}
              onChange={handleChange}
              className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-semibold text-zinc-900"
            />
            <span className="absolute left-3 top-2.5 text-zinc-400 font-bold text-sm">₹</span>
          </div>
        </div>

        {/* Monthly Income */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Net Monthly Income (INR)</label>
          <div className="relative">
            <input
              type="number"
              name="monthlyIncome"
              required
              value={formData.monthlyIncome}
              onChange={handleChange}
              className="w-full pl-4 pr-12 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
            />
            <span className="absolute right-3 top-3 text-[10px] font-mono text-zinc-400 font-bold">/Month</span>
          </div>
        </div>

        {/* Existing EMIs */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Existing EMIs Outgo (INR)</label>
          <div className="relative">
            <input
              type="number"
              name="existingEMIs"
              required
              value={formData.existingEMIs}
              onChange={handleChange}
              className="w-full pl-4 pr-12 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
            />
            <span className="absolute right-3 top-3 text-[10px] font-mono text-zinc-400 font-bold">/Month</span>
          </div>
        </div>

        {/* Credit History (CIBIL Score) */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Credit Bureau score (CIBIL)</label>
          <input
            type="number"
            name="creditBureauScore"
            required
            min="300"
            max="900"
            value={formData.creditBureauScore}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-extrabold text-zinc-950"
          />
        </div>

        {/* Years of employment */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Employment Tenure (Years)</label>
          <input
            type="number"
            name="employmentStabilityYears"
            required
            min="0"
            step="0.5"
            value={formData.employmentStabilityYears}
            onChange={handleChange}
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-950"
          />
        </div>

        {/* Identity Details */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">PAN Verification Code (10 Chars)</label>
          <input
            type="text"
            name="panNumber"
            required
            value={formData.panNumber}
            onChange={handleChange}
            placeholder="BMKPS1234F"
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-mono tracking-wider text-zinc-900"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Aadhaar Verification Code</label>
          <input
            type="text"
            name="aadhaarNumber"
            required
            value={formData.aadhaarNumber}
            onChange={handleChange}
            placeholder="4820 1930 2049"
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-mono tracking-wider text-zinc-900"
          />
        </div>

        {/* Address */}
        <div className="col-span-1 md:col-span-2 space-y-1.5">
          <label className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">Current Residential Address</label>
          <input
            type="text"
            name="address"
            required
            value={formData.address}
            onChange={handleChange}
            placeholder="Flat 102, Building 4C, Noida Sector 55, Uttar Pradesh"
            className="w-full px-4 py-2.5 rounded-lg border border-zinc-200 text-sm focus:border-black focus:ring-1 focus:ring-black outline-none font-medium text-zinc-900"
          />
        </div>

      </div>

      {/* Real-time calculated Risk Indicator banner */}
      <div className="p-4 rounded-lg bg-zinc-50 border border-zinc-200 space-y-2 text-xs">
        <h4 className="font-mono text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1">
          <ShieldAlert className="w-4 h-4 text-zinc-500" />
          Pre-appraisal Debt Capacity Check
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div>
            <p className="text-zinc-500">Current Debt Burden (DTI Ratio):</p>
            <p className={`font-bold text-sm mt-0.5 ${currentDti > 45 ? 'text-rose-500' : 'text-zinc-800'}`}>
              {currentDti}% {currentDti > 45 ? '(Stressed)' : '(PRUDENT)'}
            </p>
          </div>
          <div>
            <p className="text-zinc-500">Projected Post-Approval DTI Ceiling:</p>
            <p className={`font-bold text-sm mt-0.5 ${projectedDti > 50 ? 'text-rose-500' : 'text-emerald-600'}`}>
              {projectedDti}% {projectedDti > 50 ? '(Exceeds guidelines)' : '(Within Safe Limits)'}
            </p>
          </div>
        </div>
      </div>

      <div className="pt-3 flex justify-end">
        <button
          type="submit"
          disabled={loading}
          className="inline-flex items-center gap-2 bg-black hover:bg-zinc-850 hover:shadow-lg text-white font-medium text-sm px-6 py-3 rounded-lg shadow-md transition-all cursor-pointer"
          id="btn-personal-form-submit"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              Running Scoring Engine...
            </>
          ) : (
            <>
              Submit and Scoring Engine
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>

    </form>
  );
}
