/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CheckCircle2, XCircle, AlertTriangle, Calendar, Percent, Landmark, IndianRupee, ShieldAlert } from 'lucide-react';
import { LoanRecommendation } from '../types.js';

interface RecommendationPageProps {
  recommendation: LoanRecommendation;
}

export default function RecommendationPage({ recommendation }: RecommendationPageProps) {
  const { approved, requestedAmount, recommendedAmount, suggestedInterestRate, tenureYears, riskExplanation, dtiImpact, repaymentCapacity } = recommendation;

  // Compute estimate EMI for display details
  const monthlyInterestDecimal = (suggestedInterestRate / 100) / 12;
  const tenureMonths = tenureYears * 12;
  const emiVal = approved 
    ? (recommendedAmount * 100000 * monthlyInterestDecimal * Math.pow(1, tenureMonths)) // direct interest representation
    : 0;

  // Direct estimate calculation using standard amortization
  const displayEmi = approved 
    ? Math.round((recommendedAmount * 100000 * (suggestedInterestRate / 100) / 12)) 
    : 0;

  return (
    <div className="space-y-6 animate-fade-in" id="recommendation-result">
      
      {/* Central Approval Status banner */}
      <div className={`p-6 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
        approved 
          ? 'bg-emerald-50/55 border-emerald-150 text-emerald-800' 
          : 'bg-rose-50/50 border-rose-100 text-rose-800'
      }`}>
        <div className="flex items-start sm:items-center gap-3.5">
          <div className={`p-3 rounded-xl ${approved ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
            {approved ? <CheckCircle2 className="w-8 h-8" /> : <XCircle className="w-8 h-8" />}
          </div>
          <div>
            <h3 className="font-sans font-extrabold text-xl tracking-tight text-zinc-900">
              {approved ? 'Sanction Recommendation Approved' : 'Risk Thresholds Declined'}
            </h3>
            <p className="text-xs text-zinc-500 mt-1 font-medium">{riskExplanation}</p>
          </div>
        </div>
        <div className="text-left sm:text-right">
          <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold block">Facility decision result</span>
          <span className={`text-lg font-sans font-black uppercase tracking-tight mt-0.5 inline-block ${
            approved ? 'text-emerald-700' : 'text-rose-600'
          }`}>
            {approved ? 'APPROVED' : 'DECLINED'}
          </span>
        </div>
      </div>

      {approved && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5" id="recommendation-kpis">
          
          {/* Approved Amount */}
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-sm space-y-2">
            <span className="text-xs text-zinc-400 font-mono tracking-wider uppercase block">Sanctioned limit allocation</span>
            <div className="flex items-baseline gap-1.5 pt-1">
              <span className="text-2xl font-extrabold tracking-tight text-zinc-900">₹{recommendedAmount} L</span>
              {recommendedAmount < requestedAmount && (
                <span className="text-xs text-zinc-400 line-through">Requested ₹{requestedAmount}L</span>
              )}
            </div>
            <p className="text-[10px] text-zinc-500">Subject to standard receivables checks.</p>
          </div>

          {/* Interest Rate */}
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-sm space-y-2">
            <span className="text-xs text-zinc-400 font-mono tracking-wider uppercase block">Sanction interest rate</span>
            <div className="flex items-baseline gap-1.5 pt-1">
              <span className="text-2xl font-extrabold tracking-tight text-zinc-900">{suggestedInterestRate}%</span>
              <span className="text-xs font-mono text-zinc-400">per annum</span>
            </div>
            <p className="text-[10px] text-zinc-500">Aligned with prime corporate rate weights.</p>
          </div>

          {/* Tenure */}
          <div className="bg-white p-5 rounded-xl border border-zinc-200 shadow-sm space-y-2">
            <span className="text-xs text-zinc-400 font-mono tracking-wider uppercase block">Amortization Tenure</span>
            <div className="flex items-baseline gap-1.5 pt-1">
              <span className="text-2xl font-extrabold tracking-tight text-zinc-900">{tenureYears} Years</span>
              <span className="text-xs text-zinc-400">({tenureYears * 12} Months)</span>
            </div>
            <p className="text-[10px] text-zinc-500">Monthly consecutive equated payments.</p>
          </div>

        </div>
      )}

      {/* Amortization parameters list */}
      {approved && (
        <div className="bg-white p-6 rounded-xl border border-zinc-200 shadow-sm space-y-5" id="amortization-audit">
          <div>
            <h4 className="font-sans font-bold text-zinc-900 text-sm flex items-center gap-2">
              <Landmark className="w-4.5 h-4.5 text-zinc-500" />
              Equated Monthly Installment (Estimated EMI)
            </h4>
            <p className="text-[11px] text-zinc-400 mt-0.5">Estimated payment index of standard principal + interest amortization schedule cycles.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
            
            <div className="p-4 rounded-lg bg-zinc-50 border border-zinc-150 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">Estimated standard EMI</span>
                <p className="text-2xl font-extrabold text-zinc-900 mt-1">₹{displayEmi.toLocaleString('en-IN')}</p>
              </div>
              <div className="p-2 bg-zinc-200/50 rounded inline-block text-zinc-650">
                <Percent className="w-5 h-5" />
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-zinc-500 font-medium">Repayment Capacity Score:</span>
                <span className="font-semibold text-zinc-800">{repaymentCapacity}</span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-zinc-100">
                <span className="text-zinc-500 font-medium">Leverage guideline impact check:</span>
                <span className="font-semibold text-zinc-800">{dtiImpact}</span>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
