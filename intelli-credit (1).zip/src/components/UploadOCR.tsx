/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle2, AlertCircle, Sparkles, FolderOpen, ArrowRight } from 'lucide-react';
import { LoanType } from '../types.js';

interface UploadOCRProps {
  onParsedResult: (data: any, loanType: LoanType) => void;
  activeLoanType: LoanType;
}

export default function UploadOCR({ onParsedResult, activeLoanType }: UploadOCRProps) {
  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Pre-loaded high-fidelity sandbox files for demonstration
  const OCR_PRESETS = {
    [LoanType.PERSONAL]: [
      {
        title: 'Form 16 - Vijay Sharma (Tier-1 Tech Salaried)',
        description: 'Monthly income Certificate of salary with standard deductions & employer metadata',
        targetData: {
          borrowerName: 'Vijay Kumar Sharma',
          documentType: 'Salary Slip / Form 16',
          incomeAmount: 145000,
          employerName: 'InfoTech Enterprises Ltd',
          panNumber: 'DKIPS8394L',
          aadhaarNumber: '5391 2049 8492',
          monthsVerified: 'April & May 2026',
          taxDeductions: 12500,
          stabilityAlerts: 'Strong corporate standing'
        }
      },
      {
        title: 'Form 16 - Priya Roy (SME Consultant Salaried)',
        description: 'Mid-market consultant salary statement with variable bonuses',
        targetData: {
          borrowerName: 'Priya Roy',
          documentType: 'Salary Slip / Form 16',
          incomeAmount: 85000,
          employerName: 'PixelCraft Creative Inc',
          panNumber: 'BKLPS7382F',
          aadhaarNumber: '8392 4192 1042',
          monthsVerified: 'March to May 2026',
          taxDeductions: 4500,
          stabilityAlerts: 'Shorter career tenure'
        }
      }
    ],
    [LoanType.BUSINESS]: [
      {
        title: 'Zenith Logistics - Signed Audited Balance sheet',
        description: 'Annual GST files and verified revenue, liability, asset ratios',
        targetData: {
          borrowerName: 'Zenith Logistics & Supply Private Limited',
          documentType: 'Profit & Loss Statement / Balance Sheet',
          annualTurnover: 280.0, // ₹2.8 Cr
          netProfit: 34.5, // 34.5L
          currentAssets: 54.0,
          currentLiabilities: 29.6,
          interestExpenses: 4.5,
          ebitda: 52.0,
          totalLiabilities: 110.0,
          totalEquity: 170.0,
          panNumber: 'AAACZ5984A',
          gstNumber: '27AAPCZ5984A1ZS',
          address: 'Building A3, MIDC Industrial Area, Pune, Maharashtra 411018'
        }
      },
      {
        title: 'Aura Organic Foods - MSME Balance sheets',
        description: 'Retail trading turnover values with elevated leverage metrics',
        targetData: {
          borrowerName: 'Aura Organic Foods Trade',
          documentType: 'Profit & Loss / Audited balance sheets',
          annualTurnover: 120.0, // 1.2 Crore
          netProfit: 4.2, // 4.2 L
          currentAssets: 18.0,
          currentLiabilities: 22.0,
          interestExpenses: 2.5,
          ebitda: 8.8,
          totalLiabilities: 38.0,
          totalEquity: 22.0,
          panNumber: 'AAAGO4018D',
          gstNumber: '27AAAEO4018D1ZS',
          address: 'Ganesh Krupa Compound, Thane, Maharashtra 411601'
        }
      }
    ]
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processFileBase64 = async (file: File) => {
    setLoading(true);
    setStatus('Running Google Gemini multi-modal OCR parsing on document...');
    setError(null);

    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Str = (reader.result as string).split(',')[1];
        
        // POST to backend OCR router
        const res = await fetch('/api/upload-documents', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileBase64: base64Str,
            fileName: file.name,
            mimeType: file.type,
            loanType: activeLoanType
          })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Server OCR error');

        setStatus('OCR Extraction completed. Syncing into data fields.');
        setTimeout(() => {
          onParsedResult(data.extractedInfo, activeLoanType);
          setLoading(false);
          setStatus(null);
        }, 1000);
      };
    } catch (err: any) {
      console.error('OCR Process failed:', err);
      setError(err.message || 'Verification failed. Try using presets below.');
      setLoading(false);
      setStatus(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFileBase64(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFileBase64(e.target.files[0]);
    }
  };

  const loadPreset = (preset: any) => {
    setLoading(true);
    setStatus('Simulating secure high-fidelity secure parsing client side...');
    setTimeout(() => {
      onParsedResult(preset.targetData, activeLoanType);
      setLoading(false);
      setStatus(null);
    }, 850);
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-zinc-200 shadow-sm space-y-6" id="upload-ocr-workspace">
      <div>
        <h3 className="font-sans font-bold text-zinc-900 flex items-center gap-2">
          <FileText className="w-5 h-5 text-zinc-500" />
          Document Ingestion & AI OCR
        </h3>
        <p className="text-zinc-500 text-xs mt-1">
          Upload balance sheets, Aadhaar card, Form 16s, or GST filings (PDF, Images, JPEG). 
          Gemini will parse structured assets directly.
        </p>
      </div>

      {/* Drag & Drop Visual Box */}
      <div
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
          dragActive 
            ? 'border-black bg-zinc-50' 
            : 'border-zinc-200 hover:border-zinc-400 hover:bg-zinc-50/50'
        }`}
        id="drag-drop-zone-area"
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileInput}
          className="hidden"
          accept=".pdf,.png,.jpg,.jpeg"
        />
        
        {loading ? (
          <div className="space-y-3 flex flex-col items-center py-4">
            <div className="w-8 h-8 border-4 border-zinc-200 border-t-black rounded-full animate-spin" />
            <p className="text-xs font-mono text-zinc-500">{status}</p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="p-3 bg-zinc-100 rounded-full inline-block text-zinc-700">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <p className="font-medium text-sm text-zinc-850">
                Drag and drop your document here, or <span className="text-black underline font-bold">browse</span>
              </p>
              <p className="text-[11px] text-zinc-400 mt-1">Supports PDF, JPG, PNG, scanned files (max 20MB)</p>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-100 text-rose-800 text-xs p-3 rounded-lg flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
          <p className="font-medium">{error}</p>
        </div>
      )}

      {/* Preset Sandboxed Samples */}
      <div className="space-y-3 pt-2">
        <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-zinc-500" />
          Borrower Document Presets (No file needed)
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {OCR_PRESETS[activeLoanType].map((preset, idx) => (
            <button
              onClick={() => loadPreset(preset)}
              key={idx}
              className="text-left p-3.5 rounded-lg border border-zinc-150 hover:border-zinc-900 bg-zinc-50/50 hover:bg-white transition-all group flex flex-col justify-between"
              id={`preset-item-ocr-${idx}`}
            >
              <div>
                <span className="font-semibold text-xs text-zinc-800 group-hover:text-black block font-sans truncate">{preset.title}</span>
                <p className="text-[10px] text-zinc-500 mt-1 line-clamp-2 leading-relaxed">{preset.description}</p>
              </div>
              <span className="text-[10px] font-mono text-zinc-400 group-hover:text-black flex items-center gap-1 mt-2.5 font-bold transition-all">
                Load Preset <ArrowRight className="w-3 h-3 translate-x-0 group-hover:translate-x-1 transition-all" />
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
