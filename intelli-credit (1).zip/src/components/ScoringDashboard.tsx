/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, Info, CheckCircle2, TrendingUp, TrendingDown } from 'lucide-react';
import { MLPrediction, RiskCategory } from '../types.js';

interface ScoringDashboardProps {
  prediction: MLPrediction;
}

export default function ScoringDashboard({ prediction }: ScoringDashboardProps) {
  const { creditScore, probabilityOfDefault, riskCategory, factorsImpact } = prediction;

  // Gauge calculation
  // Radius of semi-circle: 40. Circumference: pi * r = 125.6
  // Dash offset: 125.6 * (1 - score / 100)
  const scorePercent = creditScore / 100;
  const dashOffset = 125.6 * (1 - scorePercent);

  // Risk colors helper
  const isLow = riskCategory === RiskCategory.LOW;
  const isHigh = riskCategory === RiskCategory.HIGH;
  const colorClass = isLow ? 'text-emerald-600' : (isHigh ? 'text-rose-500' : 'text-amber-500');
  const bgClass = isLow ? 'bg-emerald-50 border-emerald-100' : (isHigh ? 'bg-rose-50 border-rose-100' : 'bg-amber-50 border-amber-100');

  return (
    <div className="space-y-6 animate-fade-in" id="ml-prediction-section">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Rating Gauge Box */}
        <div className="bg-white p-6 rounded-xl border border-zinc-200 shadow-sm flex flex-col items-center text-center justify-center space-y-4">
          <div>
            <h4 className="font-sans font-bold text-zinc-950 text-sm">Credit scoring rating</h4>
            <p className="text-[11px] text-zinc-400 mt-0.5">Machine Learning Weighted Multi-factor Scorecard</p>
          </div>

          <div className="relative w-48 h-28 flex items-end justify-center overflow-hidden">
            <svg className="w-full h-full transform" viewBox="0 0 100 50">
              {/* Underlay grey arc */}
              <path
                d="M 10 50 A 40 40 0 0 1 90 50"
                fill="none"
                stroke="#f4f4f5"
                strokeWidth="8"
                strokeLinecap="round"
              />
              {/* Active animated rating arc */}
              <path
                d="M 10 50 A 40 40 0 0 1 90 50"
                fill="none"
                stroke={isLow ? '#10b981' : (isHigh ? '#ef4444' : '#f59e0b')}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray="125.6"
                strokeDashoffset={dashOffset}
                className="transition-all duration-1000"
              />
            </svg>
            
            {/* Value Overlay */}
            <div className="absolute text-center bottom-1 space-y-0.5">
              <span className="text-4xl font-extrabold tracking-tight text-zinc-900">{creditScore}</span>
              <p className="text-[10px] font-mono uppercase tracking-wider text-zinc-400">Score Out of 100</p>
            </div>
          </div>

          {/* Risk Level Badge */}
          <div className={`px-4 py-1.5 rounded-full border text-xs font-bold leading-none ${bgClass} ${colorClass}`}>
            Classification: {riskCategory}
          </div>
        </div>

        {/* PD (Probability of Default) and Score explanations */}
        <div className="bg-white p-6 rounded-xl border border-zinc-200 shadow-sm flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <h4 className="font-sans font-bold text-zinc-800 text-sm flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-zinc-650" />
              Empirical Probability of Default (PD)
            </h4>
            <p className="text-xs text-zinc-500 leading-relaxed">
              Calculated via dynamic risk regressions mapping historical defaults against current cash gearing, DTI outgo corridors, and credit history variables.
            </p>
          </div>

          <div className="bg-zinc-50 p-4 rounded-lg border border-zinc-150 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-400">Computed default rate PD</span>
              <p className="text-3xl font-mono font-extrabold text-zinc-900 mt-1">{(probabilityOfDefault * 100).toFixed(1)}%</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-400">System Rating tier</span>
              <p className={`font-sans font-bold text-base mt-1 ${colorClass}`}>
                {creditScore >= 80 ? 'Tier-1 Elite' : (creditScore >= 60 ? 'Tier-2 Solid' : 'Tier-3 Restrained')}
              </p>
            </div>
          </div>

          <p className="text-[10px] text-zinc-400 flex items-center gap-1">
            <Info className="w-3.5 h-3.5" /> Checked against 5,000+ simulated commercial credit datasets models.
          </p>
        </div>

      </div>

      {/* Ratios Breakdown of contributing scoring elements */}
      <div className="bg-white p-6 rounded-xl border border-zinc-200 shadow-sm space-y-4">
        <div>
          <h4 className="font-sans font-bold text-zinc-950 text-base">Scoring Contributors Analysis</h4>
          <p className="text-xs text-zinc-500 mt-0.5">Below factors represent the primary features influencing the predictive underwriting decision.</p>
        </div>

        <div className="divide-y divide-zinc-100">
          {factorsImpact.map((factor, index) => {
            const isPos = factor.impact === 'positive';
            return (
              <div key={index} className="py-3 flex items-start justify-between gap-4">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-zinc-805 text-zinc-800 block">{factor.factor}</span>
                  <p className="text-[11px] text-zinc-550 text-zinc-400 leading-relaxed">{factor.description}</p>
                </div>
                <div className="text-right flex items-center gap-2 flex-shrink-0">
                  <span className="text-xs font-mono font-extrabold bg-zinc-100 px-2.5 py-1 rounded text-zinc-900 border border-zinc-150">
                    {factor.value}
                  </span>
                  <div className={`p-1.5 rounded-full ${isPos ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50/70 text-rose-500'}`}>
                    {isPos ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
