/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Printer, Shield, ArrowDown, ClipboardSignature, ArrowRight, HelpCircle, Check, X, FileText, Globe, KeyRound } from 'lucide-react';
import { CreditAppraisalMemo, LoanType } from '../types.js';

interface AppraisalMemoViewProps {
  memo: CreditAppraisalMemo;
  onClose: () => void;
}

export default function AppraisalMemoView({ memo, onClose }: AppraisalMemoViewProps) {
  const isBusiness = memo.loanType === LoanType.BUSINESS;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-xl border border-zinc-200 shadow-sm overflow-hidden animate-fade-in" id="appraisal-memo-workspace">
      
      {/* Upper review bar (Hidden during print) */}
      <div className="px-6 py-4 bg-zinc-50 border-b border-zinc-205 border-zinc-150 flex items-center justify-between print:hidden">
        <div className="flex items-center gap-2">
          <button 
            onClick={onClose}
            className="text-xs font-semibold text-zinc-500 hover:text-black transition-all"
            id="btn-back-to-pipeline"
          >
            ← Back to Pipelines
          </button>
          <span className="text-zinc-300">|</span>
          <span className="text-xs font-mono font-bold text-zinc-400 select-all">{memo.id}</span>
        </div>
        
        <button
          onClick={handlePrint}
          className="inline-flex items-center gap-1.5 bg-black hover:bg-zinc-800 text-white text-xs font-bold px-4 py-2 rounded-lg cursor-pointer transition-all shadow-sm"
          id="btn-print-cam-pdf"
        >
          <Printer className="w-3.5 h-3.5" />
          Export / Save PDF
        </button>
      </div>

      {/* CORE MEMO CONTAINER */}
      <div className="p-8 sm:p-12 space-y-8 bg-white" id="printable-cam-report">
        
        {/* Memo Header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between pb-6 border-b-2 border-zinc-900 gap-4">
          <div className="space-y-1.5">
            <span className="text-xs font-mono text-zinc-500 font-bold uppercase tracking-wider block">Official Credit appraisal memo (CAM)</span>
            <h2 className="text-3xl font-sans font-black tracking-tight text-zinc-900 select-all">INTELLI-CREDIT PLATFORM</h2>
            <p className="text-xs text-zinc-500">Automated underwriting assessment of commercial & individual credit risk limits.</p>
          </div>
          <div className="text-left sm:text-right font-mono text-xs text-zinc-500 space-y-1">
            <p><span className="font-bold">MEMO ID:</span> {memo.id}</p>
            <p><span className="font-bold">DATE:</span> {memo.date}</p>
            <p><span className="font-bold">METHODOLOGY:</span> AI/ML Scorecard v3.1</p>
          </div>
        </div>

        {/* SECTION 1: Borrower Profile */}
        <div className="space-y-4">
          <h3 className="text-sm font-mono uppercase font-black text-zinc-900 tracking-wider pb-1 border-b border-zinc-200">
            I. BORROWER PROFILE INFORMATION ACCENT
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3.5 text-sm">
            <div className="flex justify-between py-1.5 border-b border-zinc-100">
              <span className="text-zinc-500 font-medium">Borrower Entity Name:</span>
              <span className="font-bold text-zinc-900 select-all">{memo.borrowerName}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-zinc-100">
              <span className="text-zinc-500 font-medium">Appraisal Loan Category:</span>
              <span className="font-semibold text-zinc-850 font-mono tracking-wider">{memo.loanType}</span>
            </div>
            
            {isBusiness ? (
              <>
                <div className="flex justify-between py-1.5 border-b border-zinc-100">
                  <span className="text-zinc-500 font-medium">GST Identification (GSTIN):</span>
                  <span className="font-bold text-zinc-900 font-mono tracking-wider">{memo.gstAnalysis?.gstNumber || 'N/A'}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-zinc-100">
                  <span className="text-zinc-500 font-medium">Industry Classification:</span>
                  <span className="font-bold text-zinc-850">{memo.industryType || 'MSME Service'}</span>
                </div>
              </>
            ) : (
              <>
                <div className="flex justify-between py-1.5 border-b border-zinc-100">
                  <span className="text-zinc-500 font-medium">PAN Verification Code:</span>
                  <span className="font-bold text-zinc-900 font-mono tracking-wider">{memo.personalAnalysis?.panNumber || 'BMKPS1234F'}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-zinc-100">
                  <span className="text-zinc-500 font-medium">Aadhaar Reference Code:</span>
                  <span className="font-bold text-zinc-900 font-mono tracking-wider">{memo.personalAnalysis?.aadhaarNumber || 'Verified'}</span>
                </div>
              </>
            )}

            <div className="flex justify-between py-1.5 border-b border-zinc-100 col-span-1 md:col-span-2">
              <span className="text-zinc-500 font-medium">Physical Location Address:</span>
              <span className="font-semibold text-zinc-900 text-right select-all">{memo.locationAnalysis.address}</span>
            </div>
          </div>
        </div>

        {/* SECTION 2: Financial summary / Key Ratios */}
        <div className="space-y-4">
          <h3 className="text-sm font-mono uppercase font-black text-zinc-900 tracking-wider pb-1 border-b border-zinc-200">
            II. FINANCIAL STATEMENT SUMMARY & ENGINEERED RISK RATIOS
          </h3>
          
          {isBusiness ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm pt-1">
              {/* Financial values */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Statement Audited Figures</h4>
                <div className="space-y-1.5 border border-zinc-150 rounded-lg p-4 bg-zinc-50/50">
                  <div className="flex justify-between text-xs py-1 border-b border-zinc-100">
                    <span className="text-zinc-500 font-medium">Requested Capital Facility:</span>
                    <span className="font-mono font-bold text-zinc-900">₹{memo.financialParams.requestedAmount} Lakhs</span>
                  </div>
                  <div className="flex justify-between text-xs py-1 border-b border-zinc-100">
                    <span className="text-zinc-500 font-medium">Annualized turnover volume:</span>
                    <span className="font-mono font-bold text-zinc-900">₹{memo.financialParams.annualTurnover} Lakhs</span>
                  </div>
                  <div className="flex justify-between text-xs py-1">
                    <span className="text-zinc-500 font-medium">Net Profit Margin Surplus:</span>
                    <span className="font-mono font-bold text-zinc-900">₹{memo.financialParams.netProfit} Lakhs</span>
                  </div>
                </div>
              </div>

              {/* Ratios results */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Engineered Financial Ratios</h4>
                <div className="grid grid-cols-2 gap-3.5 pt-1">
                  <div className="border border-zinc-150 p-3.5 rounded-lg text-center">
                    <span className="text-[10px] font-mono text-zinc-400 block">Debt-to-Equity Gearing</span>
                    <span className="text-lg font-mono font-bold text-zinc-850 mt-1 block">{memo.ratios?.debtToEquity}x</span>
                  </div>
                  <div className="border border-zinc-150 p-3.5 rounded-lg text-center">
                    <span className="text-[10px] font-mono text-zinc-400 block">Current Ratio Liquidity</span>
                    <span className="text-lg font-mono font-bold text-zinc-850 mt-1 block">{memo.ratios?.currentRatio}</span>
                  </div>
                  <div className="border border-zinc-150 p-3.5 rounded-lg text-center">
                    <span className="text-[10px] font-mono text-zinc-400 block">Operating EBITDA Margin</span>
                    <span className="text-base font-mono font-bold text-zinc-850 mt-1 block">{memo.ratios?.ebitdaMargin}%</span>
                  </div>
                  <div className="border border-zinc-150 p-3.5 rounded-lg text-center">
                    <span className="text-[10px] font-mono text-zinc-400 block">Interest Coverage Ratio (DSCR)</span>
                    <span className="text-base font-mono font-bold text-zinc-850 mt-1 block">{memo.ratios?.interestCoverageRatio}x</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm pt-1">
              <div className="border border-zinc-150 p-4 rounded-lg bg-zinc-50/50 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Monthly Cash Inflows & Debt Service</h4>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between py-1 border-b border-zinc-100">
                    <span className="text-zinc-500 font-medium">Monthly Assessed Net Salary:</span>
                    <span className="font-mono font-bold text-zinc-900">₹{memo.personalAnalysis?.monthlyIncome.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-zinc-100">
                    <span className="text-zinc-500 font-medium">Existing EMI Debt servicing burdens:</span>
                    <span className="font-mono font-bold text-zinc-900">₹{memo.personalAnalysis?.existingEMIs.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-zinc-500 font-medium">Income stability score:</span>
                    <span className="font-mono font-bold text-zinc-900">{memo.personalAnalysis?.incomeStabilityScore} / 100</span>
                  </div>
                </div>
              </div>

              <div className="border border-zinc-150 p-4 rounded-lg bg-zinc-50/50 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Scored personal debt capabilities</h4>
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between py-1 border-b border-zinc-100">
                    <span className="text-zinc-500 font-medium">Calculated Debt-to-Income (DTI):</span>
                    <span className="font-mono font-bold text-zinc-900">{memo.personalAnalysis?.debtToIncomeRatio}%</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-zinc-100">
                    <span className="text-zinc-500 font-medium">Employment tenure Reliability:</span>
                    <span className="font-mono font-bold text-zinc-900">{memo.personalAnalysis?.employmentReliabilityScore} / 100</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-zinc-500 font-medium">Bankstatement health grading:</span>
                    <span className="font-mono font-bold text-emerald-600">{memo.personalAnalysis?.bankStatementScore} / 100</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* GST Registration Analysis (BUSINESS ONLY) */}
        {isBusiness && memo.gstAnalysis && (
          <div className="space-y-4">
            <h3 className="text-sm font-mono uppercase font-black text-zinc-900 tracking-wider pb-1 border-b border-zinc-200">
              III. COMPLIANCE & GST AUDIT ANALYSIS
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-medium">
              <div className="p-3 bg-zinc-50 border border-zinc-150 rounded-lg text-center col-span-1">
                <span className="text-[10px] text-zinc-400 font-mono uppercase block">GST Compliance index</span>
                <span className="text-lg font-bold font-mono text-zinc-805 mt-0.5 block">{memo.gstAnalysis.complianceScore}%</span>
              </div>
              <div className="p-3 bg-zinc-50 border border-zinc-150 rounded-lg text-center col-span-1">
                <span className="text-[10px] text-zinc-400 font-mono uppercase block">Filing consistency log</span>
                <span className="text-lg font-bold font-mono text-zinc-805 mt-0.5 block">{memo.gstAnalysis.filingConsistencyScore}%</span>
              </div>
              <div className="p-3 bg-zinc-50 border border-zinc-150 rounded-lg text-center col-span-1">
                <span className="text-[10px] text-zinc-400 font-mono uppercase block">Tax registration legitimacy</span>
                <span className="text-lg font-bold font-mono text-emerald-600 mt-0.5 block">{memo.gstAnalysis.legitimacyScore}%</span>
              </div>
            </div>
            
            <table className="w-full text-left font-mono text-[10px] border-collapse bg-zinc-50 border border-zinc-150 rounded-lg overflow-hidden">
              <thead>
                <tr className="bg-zinc-100 text-zinc-550 border-b border-zinc-150">
                  <th className="px-4 py-2">Filing Period</th>
                  <th className="px-4 py-2 text-center font-bold text-zinc-900">GSTR-1 Status</th>
                  <th className="px-4 py-2 text-center font-bold text-zinc-900">GSTR-3B Status</th>
                  <th className="px-4 py-2 text-right">Reported Turnover (L)</th>
                  <th className="px-4 py-2 text-right">Tax Liabilities Paid</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-150">
                {memo.gstAnalysis.recentFilings.map((f, idx) => (
                  <tr key={idx}>
                    <td className="px-4 py-2.5 text-zinc-905">{f.period}</td>
                    <td className="px-4 py-2.5 text-center text-emerald-600 font-bold">✓ {f.gstr1Status}</td>
                    <td className="px-4 py-2.5 text-center text-emerald-600 font-bold">✓ {f.gstr3bStatus}</td>
                    <td className="px-4 py-2.5 text-right text-zinc-950 font-bold">₹{f.turnover} Lakhs</td>
                    <td className="px-4 py-2.5 text-right">₹{f.taxPaid.toFixed(2)} Lakhs</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* SECTION 3: External news, geographic risks & industry intelligence */}
        <div className="space-y-4">
          <h3 className="text-sm font-mono uppercase font-black text-zinc-900 tracking-wider pb-1 border-b border-zinc-200">
            IV. LOCAL GEOGRAPHIC, ECONOMIC & LEGAL RISK INDICES
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs leading-relaxed">
            
            <div className="border border-zinc-150 p-4 rounded-lg bg-zinc-100/50 space-y-2">
              <h4 className="font-bold text-zinc-900 font-sans text-xs">A. Geographic Micro & Macro Risks</h4>
              <div className="space-y-1.5 font-mono text-[11px]">
                <p><span className="text-zinc-500 font-medium">Growth score:</span> {memo.locationAnalysis.locationGrowthScore}/100</p>
                <p><span className="text-zinc-500 font-medium">Litigation risk:</span> {memo.locationAnalysis.locationRiskScore}/100</p>
                <p><span className="text-zinc-500 font-medium">Ecosystem:</span> {memo.locationAnalysis.infrastructureQuality}</p>
                <p><span className="text-zinc-500 font-medium">Disaster:</span> {memo.locationAnalysis.disasterRisk}</p>
              </div>
            </div>

            <div className="border border-zinc-150 p-4 rounded-lg bg-zinc-100/50 space-y-2">
              <h4 className="font-bold text-zinc-900 font-sans text-xs">B. Legal & Media News sentiment</h4>
              <p className="font-mono text-[10px] text-zinc-650 leading-relaxed">{memo.externalIntel.riskSummary}</p>
              <div className="pt-1.5 border-t border-zinc-200/50 font-mono text-[10px] text-zinc-500 flex justify-between">
                <span>Disputes count: {memo.externalIntel.legalDisputesCount}</span>
                <span className="text-emerald-600 font-bold">Sentiments: {memo.externalIntel.newsSentiment}</span>
              </div>
            </div>

            <div className="border border-zinc-150 p-4 rounded-lg bg-zinc-100/50 space-y-2">
              <h4 className="font-bold text-zinc-900 font-sans text-xs">C. Sector Outlook Intelligence</h4>
              {isBusiness && memo.industryIntel ? (
                <>
                  <p className="font-mono text-[10px] text-zinc-650 leading-relaxed">{memo.industryIntel.futureGrowthPotential}</p>
                  <p className="font-mono text-[10px] text-[10px] font-bold text-zinc-500 pt-1.5 border-t border-zinc-200/50">
                    Growth: {memo.industryIntel.industryGrowthScore} / Risk Index: {memo.industryIntel.industryRiskScore}
                  </p>
                </>
              ) : (
                <p className="font-mono text-[10px] text-zinc-500 leading-normal">
                  Sector outlook graded as Prime A+. Low credit defaults record historically reported for salaried segments.
                </p>
              )}
            </div>

          </div>
        </div>

        {/* SECTION 4: AI Financial analyst performance review */}
        <div className="space-y-4">
          <h3 className="text-sm font-mono uppercase font-black text-zinc-900 tracking-wider pb-1 border-b border-zinc-200">
            V. UNDERWRITER ANALYSIS BY GOOGLE GEMINI ANALYST
          </h3>
          <div className="border border-zinc-150 rounded-lg p-5 space-y-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-zinc-400 font-bold block">Assigned risk evaluation summary</span>
              <p className="text-zinc-800 leading-relaxed font-medium font-sans text-[13px]">{memo.aiFinancialSummary.financialHealthSummary}</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono uppercase text-emerald-600 font-bold block">Appraisal Strengths identified</span>
                <ul className="space-y-1 text-[11px] text-zinc-550 list-none pl-0">
                  {memo.aiFinancialSummary.keyStrengths.map((str, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> {str}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono uppercase text-rose-500 font-bold block">Critical constraints identified</span>
                <ul className="space-y-1 text-[11px] text-zinc-550 list-none pl-0">
                  {memo.aiFinancialSummary.keyRisks.map((risk, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-rose-400 rounded-full" /> {risk}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 5: ML scoring scorecard and Recommendation (DECISION CARD) */}
        <div className="space-y-4">
          <h3 className="text-sm font-mono uppercase font-black text-zinc-900 tracking-wider pb-1 border-b border-zinc-200">
            VI. PREDICTIVE ML SCORECARD RESULTS & SANCTION TERM DEEDS
          </h3>
          <div className="p-6 border-b border-dashed border-zinc-300 rounded-lg border border-zinc-200 grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div className="space-y-1 bg-zinc-50 p-4 rounded-lg">
              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">Predictive Underwriting rating</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-4xl font-sans font-black text-zinc-950">{memo.mlResult.creditScore}</span>
                <span className="text-xs text-zinc-400">/ 100</span>
              </div>
              <p className="text-[11px] text-zinc-500 pt-1">
                Risk Classification: <span className="font-bold underline">{memo.mlResult.riskCategory}</span> with probability of default index at {(memo.mlResult.probabilityOfDefault * 100).toFixed(1)}%.
              </p>
            </div>

            <div className="space-y-1 bg-zinc-50 p-4 rounded-lg">
              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">Sanction recommendation decision</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className={`text-3xl font-sans font-black ${memo.recommendation.approved ? 'text-emerald-700' : 'text-rose-600'}`}>
                  {memo.recommendation.approved ? 'APPROVED' : 'DECLINED'}
                </span>
              </div>
              <p className="text-[11px] text-zinc-550 text-zinc-500 mt-1">
                Limits Approved: <span className="font-bold">₹{memo.recommendation.recommendedAmount} Lakhs</span> @ <span className="font-bold">{memo.recommendation.suggestedInterestRate}% Interest</span>.
              </p>
            </div>

          </div>
        </div>

        {/* CAM Report Signature Footblock */}
        <div className="pt-12 flex flex-col sm:flex-row justify-between items-center text-xs text-zinc-400 font-mono gap-4 border-t border-zinc-200">
          <p>Verified with active digital tokens. Timestamp checks recorded as GMT 2026.</p>
          <div className="flex items-center gap-1.5">
            <ClipboardSignature className="w-4 h-4 text-zinc-500" />
            <span className="font-semibold text-zinc-800">AUTOMATED UNDERWRITING AGENT</span>
          </div>
        </div>

      </div>

    </div>
  );
}
