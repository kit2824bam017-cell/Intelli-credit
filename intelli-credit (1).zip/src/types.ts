/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum LoanType {
  PERSONAL = 'PERSONAL',
  BUSINESS = 'BUSINESS',
}

export enum RiskCategory {
  LOW = 'Low Risk',
  MEDIUM = 'Medium Risk',
  HIGH = 'High Risk',
}

export enum IndustryType {
  MANUFACTURING = 'Manufacturing',
  RETAIL = 'Retail & E-commerce',
  SERVICES = 'IT & Professional Services',
  HEALTHCARE = 'Healthcare & Pharmaceuticals',
  CONSTRUCTION = 'Construction & Real Estate',
  AGRICULTURE = 'Agriculture & Food Processing',
}

export interface GSTVerification {
  gstNumber: string;
  isValid: boolean;
  registrationStatus: string;
  businessName: string;
  registrationDate: string;
  industryType: string;
  registeredAddress: string;
  businessAgeYears: number;
  filingConsistencyScore: number; // 0-100
  complianceScore: number; // 0-100
  legitimacyScore: number; // 0-100
  recentFilings: {
    period: string;
    gstr1Status: 'Filed' | 'Pending';
    gstr3bStatus: 'Filed' | 'Pending';
    turnover: number;
    taxPaid: number;
  }[];
}

export interface FinancialRatios {
  profitMargin: number; // %
  debtToEquity: number; // ratio
  currentRatio: number; // ratio
  interestCoverageRatio: number; // ratio
  returnOnAssets: number; // %
  ebitdaMargin: number; // %
  revenueGrowthRate: number; // %
  cashFlowStability: number; // 0-100
}

export interface PersonalAnalysis {
  monthlyIncome: number;
  incomeStabilityScore: number; // 0-100
  employmentStabilityYears: number;
  employmentReliabilityScore: number; // 0-100
  debtToIncomeRatio: number; // %
  existingEMIs: number;
  currentEMIDebtburden: number;
  creditHistoryScore: number; // 300-850 scaled to 0-100
  bankStatementScore: number; // 0-100
  financialCapacityScore: number; // 0-100
  panNumber?: string;
  aadhaarNumber?: string;
}

export interface AIFinancialSummary {
  financialHealthSummary: string;
  keyStrengths: string[];
  keyRisks: string[];
  riskLevel: 'Low' | 'Medium' | 'High';
  aiRecommendations: string;
}

export interface IndustryIntelligence {
  industryGrowthScore: number; // 0-10
  industryRiskScore: number; // 0-10
  futureGrowthPotential: string;
  reasoning: string;
}

export interface LocationAnalysis {
  address: string;
  locationGrowthScore: number; // 0-100
  locationRiskScore: number; // 0-100
  infrastructureQuality: string; // High/Medium/Low
  accessibility: string;
  marketPotential: string;
  disasterRisk: string; // High/Medium/Low
}

export interface ExternalResearch {
  newsSentiment: string; // Positive/Neutral/Negative
  legalDisputesCount: number;
  litigationRiskScore: number; // 0-100
  promoterReputationScore: number; // 0-100
  externalRiskScore: number; // 0-100
  riskSummary: string;
}

export interface MLPrediction {
  creditScore: number; // 0-100 (high is better)
  probabilityOfDefault: number; // 0-1 (low is better)
  riskCategory: RiskCategory;
  factorsImpact: {
    factor: string;
    impact: 'positive' | 'negative' | 'neutral';
    value: string;
    description: string;
  }[];
}

export interface LoanRecommendation {
  approved: boolean;
  requestedAmount: number;
  recommendedAmount: number;
  suggestedInterestRate: number; // %
  tenureYears: number;
  riskExplanation: string;
  dtiImpact: string;
  repaymentCapacity: string;
}

export interface CreditAppraisalMemo {
  id: string; // ID e.g. CAM-2026-001
  date: string;
  borrowerName: string;
  loanType: LoanType;
  industryType?: string;
  financialParams: {
    requestedAmount: number;
    annualTurnover?: number;
    netProfit?: number;
    monthlySalary?: number;
  };
  gstAnalysis?: GSTVerification;
  ratios?: FinancialRatios;
  personalAnalysis?: PersonalAnalysis;
  aiFinancialSummary: AIFinancialSummary;
  industryIntel?: IndustryIntelligence;
  locationAnalysis: LocationAnalysis;
  externalIntel: ExternalResearch;
  mlResult: MLPrediction;
  recommendation: LoanRecommendation;
}

export interface DashboardStats {
  totalApplications: number;
  averageCreditScore: number;
  approvalRate: number;
  totalApprovedAmount: number;
  distributionRisk: { name: string; value: number }[];
  volumeByType: { name: string; value: number }[];
  recentApplications: Array<{
    id: string;
    borrowerName: string;
    loanType: LoanType;
    requestedAmount: number;
    creditScore: number;
    status: 'Approved' | 'Declined' | 'Pending';
    createdAt: string;
  }>;
}
